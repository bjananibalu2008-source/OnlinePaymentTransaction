package com.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

import java.nio.charset.StandardCharsets;
import java.util.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {

private final TransactionRepository repository;
private final RestClient client = RestClient.create();

@Value("${paypal.client-id}")
private String clientId;

@Value("${paypal.client-secret}")
private String clientSecret;

@Value("${paypal.base-url}")
private String baseUrl;

public PaymentController(TransactionRepository repository) {
    this.repository = repository;
}

@GetMapping("/test")
public String test() {
    return "Working";
}

private String accessToken() {
    String credentials = Base64.getEncoder().encodeToString(
            (clientId + ":" + clientSecret)
                    .getBytes(StandardCharsets.UTF_8)
    );

    try {
        Map<?, ?> response = client.post()
                .uri(baseUrl + "/v1/oauth2/token")
                .header("Authorization", "Basic " + credentials)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body("grant_type=client_credentials")
                .retrieve()
                .body(Map.class);

        if (response == null || response.get("access_token") == null) {
            throw new IllegalStateException(
                    "PayPal did not return an access token."
            );
        }

        return (String) response.get("access_token");

    } catch (RestClientResponseException e) {
        System.err.println("PayPal token error: HTTP "
                + e.getStatusCode());
        System.err.println("PayPal response: "
                + e.getResponseBodyAsString());
        throw e;
    }
}

@PostMapping("/create-order")
public Map<String, Object> createOrder(
        @RequestBody Map<String, Object> request) {

    String name = String.valueOf(request.get("name")).trim();
    String email = String.valueOf(request.get("email")).trim();
    double amount = Double.parseDouble(
            String.valueOf(request.get("amount"))
    );

    if (name.isBlank() || email.isBlank()
            || !email.contains("@")
            || !Double.isFinite(amount)
            || amount <= 0 || amount > 10000) {

        throw new IllegalArgumentException(
                "Invalid payment details"
        );
    }

    Map<String, Object> purchaseUnit = Map.of(
            "amount", Map.of(
                    "currency_code", "USD",
                    "value", String.format(Locale.US, "%.2f", amount)
            )
    );

    Map<String, Object> orderBody = Map.of(
            "intent", "CAPTURE",
            "purchase_units", List.of(purchaseUnit)
    );

    try {
        Map<?, ?> paypalOrder = client.post()
                .uri(baseUrl + "/v2/checkout/orders")
                .header("Authorization", "Bearer " + accessToken())
                .contentType(MediaType.APPLICATION_JSON)
                .body(orderBody)
                .retrieve()
                .body(Map.class);

        // Debug information – no secret is printed
        System.out.println("PAYPAL ORDER RESPONSE: " + paypalOrder);

        if (paypalOrder == null || paypalOrder.get("id") == null) {
            throw new IllegalStateException(
                    "PayPal order ID was not returned."
            );
        }

        String orderId = String.valueOf(paypalOrder.get("id"));
        System.out.println("PAYPAL ORDER ID: " + orderId);

        Transaction transaction = new Transaction();
        transaction.setName(name);
        transaction.setEmail(email);
        transaction.setAmount(amount);
        transaction.setOrderId(orderId);
        transaction.setStatus("PENDING");

        repository.save(transaction);

        return Map.of("orderID", orderId);

    } catch (RestClientResponseException e) {
        System.err.println("PayPal create-order error: HTTP "
                + e.getStatusCode());
        System.err.println("PayPal response: "
                + e.getResponseBodyAsString());
        throw e;
    }
}

@PostMapping("/capture-order")
public Map<String, Object> captureOrder(
        @RequestBody Map<String, String> request) {

    String orderId = request.get("orderID");

    if (orderId == null || orderId.isBlank()) {
        throw new IllegalArgumentException("Missing orderID");
    }

    Transaction transaction = repository.findByOrderId(orderId)
            .orElseThrow(() ->
                    new IllegalArgumentException("Order not found"));

    if ("SUCCESS".equals(transaction.getStatus())) {
        return Map.of("status", "COMPLETED");
    }

    try {
        Map<?, ?> capture = client.post()
                .uri(baseUrl + "/v2/checkout/orders/"
                        + orderId + "/capture")
                .header("Authorization", "Bearer " + accessToken())
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of())
                .retrieve()
                .body(Map.class);

        if (capture == null) {
            throw new IllegalStateException(
                    "PayPal returned an empty capture response."
            );
        }

        String status = String.valueOf(capture.get("status"));
        System.out.println("PAYPAL CAPTURE RESPONSE: " + capture);

        if ("COMPLETED".equals(status)) {
            transaction.setStatus("SUCCESS");
            repository.save(transaction);
        }

        return Map.of("status", status);

    } catch (RestClientResponseException e) {
        System.err.println("PayPal capture error: HTTP "
                + e.getStatusCode());
        System.err.println("PayPal response: "
                + e.getResponseBodyAsString());
        throw e;
    }
}

@GetMapping("/transactions")
public List<Transaction> getTransactions() {
    return repository.findAll();
}

}